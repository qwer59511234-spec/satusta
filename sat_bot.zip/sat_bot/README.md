# SAT Bot 🎯

SAT savollarini yechib tushuntiradigan Telegram bot.

## O'rnatish

### 1. Railway ga yuklash
1. railway.app ga kir
2. "New Project" → "Deploy from GitHub repo"
3. Bu papkani GitHub ga yuklagan bo'lsang, u repo ni tanla

### 2. Environment Variables qo'shish
Railway dashboard da "Variables" bo'limiga kir va qo'sh:

```
TELEGRAM_TOKEN = sizning_telegram_token
GEMINI_API_KEY = sizning_gemini_api_key
```

### 3. Deploy!
Railway avtomatik ishga tushiradi.

## Foydalanish
- `/start` - Botni boshlash
- `/help` - Yordam
- Matn yoki rasm yubor → javob olasan!
